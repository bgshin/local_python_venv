"""
This package contains automated code tests for all other gensim packages.
"""
